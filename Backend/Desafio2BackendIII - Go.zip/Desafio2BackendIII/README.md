Add the corresponding password for the database connection to the .env file located in the /cmd directory.

Execute the db.sql script located in the root directory of the project to create the necessary tables in the database.

In the cmd folder, run the following command to start the application.
```
go run main.go
```
In addition, you can check the available endpoints in the BackendIII-Desafio2BackendIII.postman_collection.json file located in the root of the project.