package com.dh.clinica.clinica.service;


import com.dh.clinica.clinica.dto.OdontologoDTO;
import com.dh.clinica.clinica.model.Odontologo;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.util.Assert;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
@SpringBootTest
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class OdontologoServiceTest {
    @Autowired
    private IOdontologoService odontologoService;

    @Test
    @Order(1)
    public void testCrearOdontologo(){
        OdontologoDTO odontologoDTO = new OdontologoDTO();
        odontologoDTO.setNombre("Julian");
        odontologoDTO.setApellido("Alvarez");
       odontologoService.crearOdontologo(odontologoDTO);
        OdontologoDTO pacienteAraña = odontologoService.leerOdontologo(9L);
        assertTrue(pacienteAraña != null);

    }
    @Test
    @Order(2)
    public void testModificarOdontologo(){
        OdontologoDTO odontologoDTO = new OdontologoDTO();
        odontologoDTO = odontologoService.leerOdontologo(9L);
        odontologoDTO.setMatricula("09");
        odontologoService.modificarOdontologo(odontologoDTO);
        odontologoDTO = odontologoService.leerOdontologo(9L);
        assertTrue(odontologoDTO.getMatricula()!= "90");

    }
    @Test
    @Order(3)
    public void traerTodos() {
        List<OdontologoDTO> odontologos = odontologoService.getTodos();
        Assert.assertTrue(!odontologos.isEmpty());
        Assert.assertTrue(odontologos.size() == 1);
        System.out.println(odontologos);
    }