package com.dh.clinica.clinica.service;

import com.dh.clinica.clinica.dto.PacienteDTO;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.jupiter.api.Assertions.*;


@SpringBootTest
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class PacienteServiceTest {
    @Autowired
    private IPacienteService pacienteService;

    @Test
    @Order(1)
    public void testCrearPaciente(){
        PacienteDTO pacienteDTO = new PacienteDTO();
        pacienteDTO.setNombre("Lionel");
        pacienteDTO.setApellido("Messi");
        pacienteService.crearPaciente(pacienteDTO);
        PacienteDTO pacienteDios = pacienteService.leerPaciente(10L);
        assertTrue(pacienteDios != null);

    }
    @Test
    @Order(2)
    public void testLeerPaciente (){
        PacienteDTO pacienteDTO = new PacienteDTO();
        pacienteDTO = pacienteService.leerPaciente( 10L);
    }
    @Test
    @Order(3)
    public void testEliminarPaciente (){
        PacienteDTO pacienteDTO = new PacienteDTO();
        pacienteService.eliminarPaciente(10L);
        pacienteDTO = pacienteService.leerPaciente(10L);
        assertNull(pacienteDTO);
    }

}