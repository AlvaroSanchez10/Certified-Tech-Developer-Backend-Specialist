package com.dh.clinica.clinica.repository;

import com.dh.clinica.clinica.model.Paciente;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface IPacienteRepository extends JpaRepository<Paciente, Integer>{
    void save(Paciente paciente);

    Optional<Paciente> findById(Long id);
}
