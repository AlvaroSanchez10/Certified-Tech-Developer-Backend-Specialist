package com.dh.clinica.clinica.service;

import com.dh.clinica.clinica.dto.OdontologoDTO;
import com.dh.clinica.clinica.dto.PacienteDTO;

import java.util.Set;

public interface IOdontologoService {
    void crearOdontologo (OdontologoDTO odontologoDTO);
    OdontologoDTO leerOdontologo(Long id);
    void modificarOdontologo (OdontologoDTO odontologoDTO);
    void eliminarOdontologo(Long id);
    Set<OdontologoDTO> getTodos();

}
