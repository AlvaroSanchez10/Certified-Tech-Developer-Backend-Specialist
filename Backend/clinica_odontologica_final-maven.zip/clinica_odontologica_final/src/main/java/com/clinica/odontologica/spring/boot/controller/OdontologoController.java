package com.clinica.odontologica.spring.boot.controller;

import com.clinica.odontologica.spring.boot.dto.ApiResponseDto;
import com.clinica.odontologica.spring.boot.dto.OdontologoRespuestaDto;
import com.clinica.odontologica.spring.boot.dto.OdontologoSolicitudDto;
import com.clinica.odontologica.spring.boot.service.OdontologoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import javax.validation.Valid;


@RestController
@RequestMapping("/odontologos")
public class OdontologoController {

    @Autowired
    OdontologoService odontologoService;


    @PostMapping("/guardar")
    public ResponseEntity<?> guardarOdontologo(@Valid @RequestBody OdontologoSolicitudDto odontologo) {
         var odontologoRespuestaDto= odontologoService.guardarOdontologo(odontologo);
        return ResponseEntity.status(HttpStatus.CREATED).body(ApiResponseDto.created(odontologoRespuestaDto,
                "Odontologo guardado con Exito", HttpStatus.CREATED));
    }


    @GetMapping("/{id}")
    public ResponseEntity<?> consultarOdontologoPorId(@PathVariable("id") Long id) {
        var odontologoRespuestaDto= odontologoService.buscarOdontologoPorId(id);
        return ResponseEntity.ok().body(ApiResponseDto.created(odontologoRespuestaDto,
                "Odontologo encontrado con exito",HttpStatus.OK));
    }


    @PutMapping("/actualizar/{id}")
    public ResponseEntity<?> actualizarOdontologoPorId(@PathVariable("id") Long id, @RequestBody OdontologoSolicitudDto odontologoSolicitudDto) {
        var odontologoActualizado = odontologoService.actualizarOdontologoPorId(id, odontologoSolicitudDto);
        return ResponseEntity.ok().body(ApiResponseDto.created(odontologoActualizado,
                "Datos actualizados correctamente",HttpStatus.OK));
    }


    @GetMapping("/list")
    public ResponseEntity<ApiResponseDto<List<OdontologoRespuestaDto>>>listarOdontologos() {
        var listOdontologoRespuestaDto= odontologoService.listarOdontologos();
        return ResponseEntity.ok().body(ApiResponseDto.created(listOdontologoRespuestaDto,
                "Listado de Odontologos", HttpStatus.OK));
    }


    @DeleteMapping("/{id}")
    public ResponseEntity<?> eliminarOdontologoPorId(@PathVariable("id") Long id) {
        odontologoService.eliminarOdontolgoPorId(id);
        return ResponseEntity.ok().body(ApiResponseDto.created(null, "Odontologo eliminado con exito", HttpStatus.NO_CONTENT));
    }


}
