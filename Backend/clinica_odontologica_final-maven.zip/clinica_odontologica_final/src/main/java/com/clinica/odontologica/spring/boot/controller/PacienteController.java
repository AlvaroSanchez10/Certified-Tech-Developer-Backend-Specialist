package com.clinica.odontologica.spring.boot.controller;


import com.clinica.odontologica.spring.boot.dto.ApiResponseDto;
import com.clinica.odontologica.spring.boot.dto.PacienteRespuestaDto;
import com.clinica.odontologica.spring.boot.dto.PacienteSolicitudDto;
import com.clinica.odontologica.spring.boot.service.PacienteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/pacientes")
public class PacienteController {

    @Autowired
    PacienteService pacienteService;

    @PostMapping("/registrar-paciente")
    public ResponseEntity<?> registrarPaciente(@Valid @RequestBody PacienteSolicitudDto paciente) {
        var pacienteRespuestaDto = pacienteService.registrarPaciente(paciente);
        return ResponseEntity.status(HttpStatus.CREATED).body(ApiResponseDto.created(pacienteRespuestaDto,
                "Paciente registrado con Exito", HttpStatus.CREATED));

    }


    @GetMapping("/buscar-paciente")
    public ResponseEntity<?> consultarPacientePorDocumento(@RequestParam(value = "documento", required = false) String documento) {
        var pacienteDto = pacienteService.consultarPacientePorDocumento(documento);
        return ResponseEntity.ok().body(ApiResponseDto.created(pacienteDto,
                "Paciente encontrado con exito", HttpStatus.OK));
    }


    @PutMapping("/actualizar-paciente/{id}")
    public ResponseEntity<?> actualizarDatosPaciente(@PathVariable(value = "id", required = false) Long id, @RequestBody PacienteSolicitudDto pacienteSolicitudDto) {
        var pacienteActualizado = pacienteService.actualizarDatosPaciente(id, pacienteSolicitudDto);

        return ResponseEntity.ok().body(ApiResponseDto.created(pacienteActualizado,
                "Datos actualizados correctamente", HttpStatus.OK));
    }


    @GetMapping("/lista-pacientes")
    public ResponseEntity<ApiResponseDto<List<PacienteRespuestaDto>>> listarPacientes() {
        var listaPacientesDto = pacienteService.listarPacientes();

        return ResponseEntity.ok().body(ApiResponseDto.created(listaPacientesDto,
                "Listado de Pacientes", HttpStatus.OK));
    }


    @DeleteMapping("eliminar-paciente/{id}")
    public ResponseEntity<?> eliminarPaciente(@PathVariable("id") Long id) {
        pacienteService.eliminarPaciente(id);
        return ResponseEntity.ok().body(ApiResponseDto.created(null, "Paciente eliminado con exito", HttpStatus.NO_CONTENT));
    }

}
