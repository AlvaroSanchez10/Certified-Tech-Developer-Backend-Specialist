package com.clinica.odontologica.spring.boot.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.http.HttpStatus;

import java.io.Serializable;


@Builder
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ApiResponseDto<T> implements Serializable {

    private T data;
    private String message;
    private HttpStatus status;
    private int statusCode;

    public static <T> ApiResponseDto<T> created(T data, String message, HttpStatus status) {
        return new ApiResponseDto<T>(data, message, status, status.value());
    }

    public static <T> ApiResponseDto<T> created(String message, HttpStatus status) {
        return new ApiResponseDto<T>(null, message, status, status.value());
    }
}
