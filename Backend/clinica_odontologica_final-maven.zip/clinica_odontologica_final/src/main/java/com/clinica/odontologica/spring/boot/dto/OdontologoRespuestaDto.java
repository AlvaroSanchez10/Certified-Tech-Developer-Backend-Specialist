package com.clinica.odontologica.spring.boot.dto;

import com.clinica.odontologica.spring.boot.model.Odontologo;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
@Builder
public class OdontologoRespuestaDto implements Serializable {

    private Long id;
    private String nombre;
    private String apellido;
    private String numeroMatricula;

    public static OdontologoRespuestaDto odontologoModelAOdontologoRespuesta(Odontologo odontologo) {
        return OdontologoRespuestaDto.builder()
                .id(odontologo.getId())
                .nombre(odontologo.getNombre())
                .apellido(odontologo.getApellido())
                .numeroMatricula(odontologo.getNumeroMatricula())
                .build();
    }

    public static List<OdontologoRespuestaDto> odontologoListAOdontologoDto(List<Odontologo> list) {

        if (list == null) {
            return null;
        }

        List<OdontologoRespuestaDto> odontologoList = new ArrayList<>(list.size());
        for (Odontologo odontologo : list) {
            odontologoList.add(odontologoModelAOdontologoRespuesta(odontologo));
        }
        return odontologoList;
    }

}
