package com.clinica.odontologica.spring.boot.dto;

import com.clinica.odontologica.spring.boot.model.Odontologo;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import java.io.Serializable;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class OdontologoSolicitudDto implements Serializable {

    @NotNull(message = "El campo requerido no puede ser nulo")
    @NotBlank(message = "El campo requerido no puede quedar en blanco")
    @Pattern(regexp = "[a-zA-Z\\s]*", message = "Solo esta permitido caracteres Alfabeticos")
    private String nombre;
    @NotNull(message = "El campo requerido no puede ser nulo")
    @NotBlank(message = "El campo requerido no puede quedar en blanco")
    @Pattern(regexp = "[a-zA-Z\\s]*", message = "Solo esta permitido caracteres Alfabeticos")
    private String apellido;
    @NotNull(message = "El campo requerido no puede ser nulo")
    @NotBlank(message = "El campo requerido no puede quedar en blanco")
    @Pattern(regexp = "^([a-zA-Z0-9])*", message = "No esta permitido caracteres especiales")
    private String numeroMatricula;


    public static Odontologo odontologoDtoAOdontologoModel(OdontologoSolicitudDto odontologoSolicitudDto) {
        return Odontologo.builder()
                .nombre(odontologoSolicitudDto.nombre)
                .apellido(odontologoSolicitudDto.apellido)
                .numeroMatricula(odontologoSolicitudDto.numeroMatricula)
                .build();
    }

}
