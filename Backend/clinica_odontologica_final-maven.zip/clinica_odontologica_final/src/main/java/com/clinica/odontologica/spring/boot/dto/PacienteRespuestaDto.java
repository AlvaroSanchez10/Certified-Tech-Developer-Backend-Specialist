package com.clinica.odontologica.spring.boot.dto;

import com.clinica.odontologica.spring.boot.model.Domicilio;
import com.clinica.odontologica.spring.boot.model.Paciente;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
@Builder
@Data
public class PacienteRespuestaDto implements Serializable {

    private String nombre;
    private String apellido;
    private String documentoIdentidad;
    private String fechaAlta;
    private Domicilio domicilio;

    public static PacienteRespuestaDto pacienteEntityAPacienteRespuestaDto(Paciente paciente) {

        return PacienteRespuestaDto.builder()
                .apellido(paciente.getApellido())
                .nombre(paciente.getNombre())
                .documentoIdentidad(paciente.getDocumentoIdentidad())
                .fechaAlta(paciente.getFechaAlta())
                .domicilio(paciente.getDomicilio())
                .build();
    }

    public static List<PacienteRespuestaDto> pacienteListAPacienteResopuestaDto(List<Paciente> list) {

        if (list == null) {
            return null;
        }

        List<PacienteRespuestaDto> pacienteList = new ArrayList<>(list.size());
        for (Paciente paciente : list) {
            pacienteList.add(pacienteEntityAPacienteRespuestaDto(paciente));
        }
        return pacienteList;
    }

}
