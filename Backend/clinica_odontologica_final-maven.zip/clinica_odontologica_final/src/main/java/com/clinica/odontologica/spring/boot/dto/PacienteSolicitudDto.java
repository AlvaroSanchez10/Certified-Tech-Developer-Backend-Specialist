package com.clinica.odontologica.spring.boot.dto;

import com.clinica.odontologica.spring.boot.model.Domicilio;
import com.clinica.odontologica.spring.boot.model.Paciente;
import com.clinica.odontologica.spring.boot.model.Turno;
import com.clinica.odontologica.spring.boot.util.ParseDate;
import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.Date;
import java.util.Set;

@Getter
@Setter
public class PacienteSolicitudDto implements Serializable {


    private String nombre;
    private String apellido;
    private String documentoIdentidad;
    private String fechaAlta;
    private Domicilio domicilio;

    @JsonIgnore
    private Set<Turno> turnos;


    public static Paciente pacienteDtoAPacienteEntity(PacienteSolicitudDto solicitudDto) {

        return Paciente.builder()
                .nombre(solicitudDto.nombre)
                .apellido(solicitudDto.apellido)
                .documentoIdentidad(solicitudDto.documentoIdentidad)
                .fechaAlta(ParseDate.formatearFecha(new Date()))
                .domicilio(new Domicilio(solicitudDto.getDomicilio().getId(),solicitudDto.getDomicilio().getCalle(),solicitudDto.getDomicilio().getNumero(),
                        solicitudDto.getDomicilio().getLocalidad(),solicitudDto.getDomicilio().getProvincia()))
                .turnos(solicitudDto.getTurnos())
                .build();
    }

}
