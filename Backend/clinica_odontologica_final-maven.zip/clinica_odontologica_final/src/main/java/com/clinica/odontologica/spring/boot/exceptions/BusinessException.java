package com.clinica.odontologica.spring.boot.exceptions;

public class BusinessException extends Exception{

    public BusinessException(String message) {
        super(message);
    }
}
