package com.clinica.odontologica.spring.boot.exceptions;

import com.clinica.odontologica.spring.boot.dto.APIErrorDto;
import com.clinica.odontologica.spring.boot.dto.ApiResponseDto;
import org.apache.log4j.Logger;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import java.util.List;
import java.util.stream.Collectors;

@ControllerAdvice
public class GlobalExceptionHandler extends ResponseEntityExceptionHandler {


    private static final Logger LOGGER = Logger.getLogger(GlobalExceptionHandler.class);


    @ExceptionHandler(Exception.class)
    public ResponseEntity<?>logError(Exception exception, WebRequest request){
        LOGGER.error(exception.getMessage());
        return new ResponseEntity<>("Error -> "+ exception.getMessage(), HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(value = BusinessException.class)
    public ResponseEntity<?> exception(BusinessException ex) {
        var response = ApiResponseDto.created(ex.getMessage(), HttpStatus.NOT_FOUND);
        return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
    }



    /**
     * Capturador de errores de validacion Dto @Valid
     */

    @Override
    protected ResponseEntity<Object> handleMethodArgumentNotValid(
            MethodArgumentNotValidException ex,
            HttpHeaders headers,
            HttpStatus status,
            WebRequest request) {

        List<String> errors = getMessageErrors(ex.getBindingResult());

        var apiError = APIErrorDto.created(null, "La solicitud contiene errores", HttpStatus.BAD_REQUEST, errors);

        return new ResponseEntity<>(apiError, headers, HttpStatus.BAD_REQUEST);

    }

    private List<String> getMessageErrors(BindingResult bindingResult) {

        List<String> errors = bindingResult
                .getFieldErrors()
                .stream()
                .map(x -> x.getField() + ": " + x.getDefaultMessage())
                .collect(Collectors.toList());

        errors.addAll(bindingResult
                .getGlobalErrors()
                .stream()
                .map(x -> x.getObjectName() + ": " + x.getDefaultMessage())
                .toList());

        return errors;

    }

}
