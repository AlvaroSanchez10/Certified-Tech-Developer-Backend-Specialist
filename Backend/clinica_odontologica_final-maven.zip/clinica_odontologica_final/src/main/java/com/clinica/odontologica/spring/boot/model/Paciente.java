package com.clinica.odontologica.spring.boot.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.*;
import org.hibernate.annotations.SQLDelete;
import org.hibernate.annotations.Where;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Set;

@Builder
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "PACIENTES")
@SQLDelete(sql = "UPDATE PACIENTES SET ELIMINADO = true WHERE id=?")
@Where(clause = "ELIMINADO=false")
public class Paciente implements Serializable {


    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "NOMBRE")
    private String nombre;

    @Column(name = "APELLIDO")
    private String apellido;

    @Column(name = "DNI")
    private String documentoIdentidad;

    @Column(name = "FECHA_ALTA")
    private String fechaAlta;

    @OneToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
    @JoinColumn(name = "domicilio_id", referencedColumnName = "id")
    @JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
    private Domicilio domicilio;

    @JsonIgnore
    @OneToMany(mappedBy = "paciente")
    private Set<Turno> turnos;

    @Column(name = "ELIMINADO", nullable = true)
    private boolean status = Boolean.FALSE;


}
