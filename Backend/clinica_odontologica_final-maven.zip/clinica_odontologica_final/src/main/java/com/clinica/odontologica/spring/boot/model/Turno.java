package com.clinica.odontologica.spring.boot.model;


import lombok.*;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "TURNOS")
public class Turno implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "PACIENTE_ID", nullable = false)
    private Paciente paciente;

    @ManyToOne
    @JoinColumn(name = "ODONTOLOGO_ID", nullable = false)
    private Odontologo odontologo;

    @Column
    private Date fechaTurno;

}
