package com.clinica.odontologica.spring.boot.repository;

import com.clinica.odontologica.spring.boot.model.Odontologo;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface OdontologoRepository extends JpaRepository<Odontologo, Long> {
}
