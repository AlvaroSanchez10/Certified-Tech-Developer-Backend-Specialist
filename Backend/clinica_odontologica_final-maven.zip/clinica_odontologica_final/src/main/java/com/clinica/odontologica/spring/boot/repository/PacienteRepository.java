package com.clinica.odontologica.spring.boot.repository;

import com.clinica.odontologica.spring.boot.model.Paciente;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface PacienteRepository extends JpaRepository<Paciente, Long> {


    @Query(nativeQuery = true, value = "SELECT * FROM PACIENTES WHERE DNI = :documento")
    Optional<Paciente> buscarPacientePorDocumento(String documento);
}
