package com.clinica.odontologica.spring.boot.repository;

import com.clinica.odontologica.spring.boot.model.Turno;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TurnoRepository extends JpaRepository<Turno, Long> {
}
