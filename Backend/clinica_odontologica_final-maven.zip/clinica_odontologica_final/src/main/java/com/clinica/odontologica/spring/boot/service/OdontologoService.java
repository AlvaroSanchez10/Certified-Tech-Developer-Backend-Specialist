package com.clinica.odontologica.spring.boot.service;

import com.clinica.odontologica.spring.boot.dto.OdontologoRespuestaDto;
import com.clinica.odontologica.spring.boot.dto.OdontologoSolicitudDto;

import java.util.List;

public interface OdontologoService {

    OdontologoRespuestaDto guardarOdontologo(OdontologoSolicitudDto odontologoSolicitudDto);

    List<OdontologoRespuestaDto> listarOdontologos();

    OdontologoRespuestaDto buscarOdontologoPorId(Long id);

    void eliminarOdontolgoPorId(Long id);

    OdontologoRespuestaDto actualizarOdontologoPorId(Long id, OdontologoSolicitudDto odontologoSolicitudDto);
}
