package com.clinica.odontologica.spring.boot.service;

import com.clinica.odontologica.spring.boot.dto.PacienteRespuestaDto;
import com.clinica.odontologica.spring.boot.dto.PacienteSolicitudDto;

import java.util.List;

public interface PacienteService {
    PacienteRespuestaDto registrarPaciente(PacienteSolicitudDto paciente);

    PacienteRespuestaDto consultarPacientePorDocumento(String documento);

    PacienteRespuestaDto actualizarDatosPaciente(Long id, PacienteSolicitudDto pacienteSolicitudDto);

    List<PacienteRespuestaDto> listarPacientes();

    void eliminarPaciente(Long id);
}
