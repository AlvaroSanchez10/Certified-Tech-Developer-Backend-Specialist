package com.clinica.odontologica.spring.boot.service;

public interface TurnoService {
}
