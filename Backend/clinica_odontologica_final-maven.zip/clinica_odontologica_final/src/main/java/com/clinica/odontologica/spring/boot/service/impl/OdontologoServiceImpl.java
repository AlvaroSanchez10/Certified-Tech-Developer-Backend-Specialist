package com.clinica.odontologica.spring.boot.service.impl;

import com.clinica.odontologica.spring.boot.dto.OdontologoRespuestaDto;
import com.clinica.odontologica.spring.boot.dto.OdontologoSolicitudDto;
import com.clinica.odontologica.spring.boot.repository.OdontologoRepository;
import com.clinica.odontologica.spring.boot.service.OdontologoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service("odontologoService")
public class OdontologoServiceImpl implements OdontologoService {


    @Autowired
    OdontologoRepository odontologRepository;

    @Override
    public OdontologoRespuestaDto guardarOdontologo(OdontologoSolicitudDto odontologoSolicitudDto) {
        var odontologo = OdontologoSolicitudDto.odontologoDtoAOdontologoModel(odontologoSolicitudDto);
        odontologRepository.save(odontologo);

        return OdontologoRespuestaDto.odontologoModelAOdontologoRespuesta(odontologo);
    }

    @Override
    public List<OdontologoRespuestaDto> listarOdontologos() {
         var listaOdontologos = odontologRepository.findAll();

        return OdontologoRespuestaDto.odontologoListAOdontologoDto(listaOdontologos);
    }

    @Override
    public OdontologoRespuestaDto buscarOdontologoPorId(Long id) {
        var odontologoModel = odontologRepository.findById(id);

        return OdontologoRespuestaDto.odontologoModelAOdontologoRespuesta(odontologoModel.get());
    }


    @Override
    public void eliminarOdontolgoPorId(Long id) {
        odontologRepository.deleteById(id);
    }

    @Override
    public OdontologoRespuestaDto actualizarOdontologoPorId(Long id, OdontologoSolicitudDto odontologoSolicitudDto) {

        var odontologoEntity = odontologRepository.findById(id);

        if (odontologoEntity.isPresent()){
            var editarOdontologo = odontologoEntity.get();

            editarOdontologo.setNombre(odontologoSolicitudDto.getNombre());
            editarOdontologo.setApellido(odontologoSolicitudDto.getApellido());
            editarOdontologo.setNumeroMatricula(odontologoSolicitudDto.getNumeroMatricula());
            odontologRepository.save(editarOdontologo);

            return OdontologoRespuestaDto.odontologoModelAOdontologoRespuesta(editarOdontologo);
        }

        throw new  RuntimeException("Error en el servicio -> actualizarOdontologoPorId ");

    }



}
