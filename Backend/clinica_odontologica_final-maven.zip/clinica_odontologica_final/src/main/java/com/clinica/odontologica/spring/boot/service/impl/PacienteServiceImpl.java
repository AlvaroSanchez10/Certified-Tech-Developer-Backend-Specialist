package com.clinica.odontologica.spring.boot.service.impl;

import com.clinica.odontologica.spring.boot.dto.PacienteRespuestaDto;
import com.clinica.odontologica.spring.boot.dto.PacienteSolicitudDto;
import com.clinica.odontologica.spring.boot.exceptions.BusinessException;
import com.clinica.odontologica.spring.boot.repository.PacienteRepository;
import com.clinica.odontologica.spring.boot.service.OdontologoService;
import com.clinica.odontologica.spring.boot.service.PacienteService;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service("pacienteService")
public class PacienteServiceImpl implements PacienteService {

    private static final Logger logger = Logger.getLogger(PacienteServiceImpl.class);

    @Autowired
    PacienteRepository pacienteRepository;


    @Override
    public PacienteRespuestaDto registrarPaciente(PacienteSolicitudDto paciente) {
        var pacienteEntity = PacienteSolicitudDto.pacienteDtoAPacienteEntity(paciente);
        pacienteRepository.save(pacienteEntity);
        return PacienteRespuestaDto.pacienteEntityAPacienteRespuestaDto(pacienteEntity);
    }

    @Override
    public PacienteRespuestaDto consultarPacientePorDocumento(String documento) {
        var pacienteEntity = pacienteRepository.buscarPacientePorDocumento(documento);
        return PacienteRespuestaDto.pacienteEntityAPacienteRespuestaDto(pacienteEntity.get());
    }

    @Override
    public PacienteRespuestaDto actualizarDatosPaciente(Long id, PacienteSolicitudDto pacienteSolicitudDto) {

        var pacienteEntity = pacienteRepository.findById(id);

        if (pacienteEntity.isPresent()){
            var editarDatosPaciente = pacienteEntity.get();

            editarDatosPaciente.setNombre(pacienteSolicitudDto.getNombre());
            editarDatosPaciente.setApellido(pacienteSolicitudDto.getApellido());
            editarDatosPaciente.setDocumentoIdentidad(pacienteSolicitudDto.getDocumentoIdentidad());

            var editarDomicilio = editarDatosPaciente.getDomicilio();
            editarDomicilio.setCalle(pacienteSolicitudDto.getDomicilio().getCalle());
            editarDomicilio.setNumero(pacienteSolicitudDto.getDomicilio().getNumero());
            editarDomicilio.setLocalidad(pacienteSolicitudDto.getDomicilio().getLocalidad());
            editarDomicilio.setProvincia(pacienteSolicitudDto.getDomicilio().getProvincia());

            pacienteRepository.save(editarDatosPaciente);

            return PacienteRespuestaDto.pacienteEntityAPacienteRespuestaDto(editarDatosPaciente);
        }

        throw new  RuntimeException("Error en el servicio -> actualizarOdontologoPorId ");

    }

    @Override
    public List<PacienteRespuestaDto> listarPacientes() {
         var listaDePacientes = pacienteRepository.findAll();

        return PacienteRespuestaDto.pacienteListAPacienteResopuestaDto(listaDePacientes);
    }

    @Override
    public void eliminarPaciente(Long id) {

        var pacienteEntity = pacienteRepository.findById(id);

        if (pacienteEntity.isPresent()) {
            var pacienteEliminado = pacienteEntity.get();
            pacienteEliminado.setStatus(true);
            pacienteRepository.save(pacienteEliminado);
            logger.info("Borrado logico exitoso para el usuario -> " + pacienteEntity.get().getNombre()+" "+pacienteEntity.get().getApellido());
        } else {
            logger.error("Ocurrio una excepcion al intentar eliminar un usuario, el Id es incorrecto o no existe");
            throw new  RuntimeException("Error en el servicio -> eliminarPaciente ");
        }
    }

}
