package com.clinica.odontologica.spring.boot.service.impl;

import com.clinica.odontologica.spring.boot.service.TurnoService;

public class TurnoServiceImpl implements TurnoService {
}
