package com.clinica.odontologica.spring.boot.util;

import org.thymeleaf.util.StringUtils;

import java.lang.constant.Constable;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;

public class ParseDate {

    public static LocalDate parse(final String dateAsString) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

        if (StringUtils.isEmpty(dateAsString)) {
            return null;
        }
        return LocalDate.parse(dateAsString, formatter);
    }


    public static String formatearFecha(Date fecha) {
        return new SimpleDateFormat("dd-MM-yyyy").format(fecha);
    }

}
