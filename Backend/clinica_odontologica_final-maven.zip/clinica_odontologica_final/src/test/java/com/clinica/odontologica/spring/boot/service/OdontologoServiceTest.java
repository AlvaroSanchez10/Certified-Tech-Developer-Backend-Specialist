package com.clinica.odontologica.spring.boot.service;

import com.clinica.odontologica.spring.boot.dto.OdontologoRespuestaDto;
import com.clinica.odontologica.spring.boot.dto.OdontologoSolicitudDto;
import org.apache.log4j.Logger;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;


import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
class OdontologoServiceTest {

    private static final Logger logger = Logger.getLogger(OdontologoServiceTest.class);

    @Autowired
    OdontologoService odontologoService;


    @BeforeClass
    public void cargarOdontologos() {
        var odontologoA = new OdontologoSolicitudDto("OdontologoA", "ApellidoA", "123123A");
        var odontologoB = new OdontologoSolicitudDto("OdontologoB", "ApellidoB", "123123B");
        var odontologoC = new OdontologoSolicitudDto("OdontologoC", "ApellidoC", "123123C");
        odontologoService.guardarOdontologo(odontologoA);
        odontologoService.guardarOdontologo(odontologoB);
        odontologoService.guardarOdontologo(odontologoC);

    }

    @Test
    void guardarOdontologo() {

        var odontologoSolicitudDto = new OdontologoSolicitudDto();
        odontologoSolicitudDto.setApellido("Messi");
        odontologoSolicitudDto.setNombre("Lionel");
        odontologoSolicitudDto.setNumeroMatricula("La10");

        odontologoService.guardarOdontologo(odontologoSolicitudDto);

        var odontologoRespuesta = odontologoService.buscarOdontologoPorId(1L);

        assertTrue(odontologoRespuesta != null);

    }

    @Test
    void listarOdontologos() {
        cargarOdontologos();
        List<OdontologoRespuestaDto> odontologos = odontologoService.listarOdontologos();
        Assert.assertTrue(odontologos.size() > 0);
        for (OdontologoRespuestaDto o : odontologos ) {
            System.out.println(o.getNombre()+" "+o.getApellido()+" "+o.getNumeroMatricula());
        }

        logger.info(odontologos);

    }

    @Test
    void buscarOdontologoPorId() {
        cargarOdontologos();
        var odontologo = odontologoService.buscarOdontologoPorId(1L);
        logger.info(odontologo);
        Assert.assertNotNull(odontologo);
        Assert.assertEquals(odontologo.getNombre(), "OdontologoA");
    }

    @Test
    void eliminarOdontolgoPorId() {
        cargarOdontologos();
        odontologoService.eliminarOdontolgoPorId(3L);
    }


}