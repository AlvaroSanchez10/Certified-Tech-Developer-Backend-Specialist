/* --------------------------- NO TOCAR DESDE ACÁ --------------------------- */
let datosPersona = {
    nombre: "",
    edad: 0,
    ciudad: "",
    interesPorJs: "",
  };
  
  const listado = [{
      imgUrl: "https://huguidugui.files.wordpress.com/2015/03/html1.png",
      lenguajes: "HTML y CSS",
      bimestre: "1er bimestre",
    },
    {
      imgUrl: "https://jherax.files.wordpress.com/2018/08/javascript_logo.png",
      lenguajes: "Javascript",
      bimestre: "2do bimestre",
    },
    {
      imgUrl: "https://upload.wikimedia.org/wikipedia/commons/thumb/4/47/React.svg/1200px-React.svg.png",
      lenguajes: "React JS",
      bimestre: "3er bimestre",
    },
  ];
  
  const profileBtn = document.querySelector("#completar-perfil");
  const materiasBtn = document.querySelector("#obtener-materias");
  const verMasBtn = document.querySelector("#ver-mas");
  const cambiarTema = document.querySelector('#cambiar-tema');
  
  profileBtn.addEventListener("click", renderizarDatosUsuario);
  materiasBtn.addEventListener("click", recorrerListadoYRenderizarTarjetas);
  cambiarTema.addEventListener("click", alternarColorTema);
  /* --------------------------- NO TOCAR HASTA ACÁ --------------------------- */
  
  function obtenerDatosDelUsuario() {
    /* --------------- PUNTO 1: Escribe tu codigo a partir de aqui --------------- */
   datosPersona.nombre = prompt ('Ingresa tu Nombre:');
   
   const hoy = new Date (); 
   const fechaNacimiento = prompt ('Ingresa el año en el que naciste:');
   datosPersona.edad = hoy.getFullYear() - fechaNacimiento 

   datosPersona.ciudad = prompt ('Ingrese la ciudad donde vives: ');
   datosPersona.interesPorJs = confirm ('Te interesa JavaScript?: ');
    if (datosPersona.interesPorJs === true) {
    datosPersona.interesPorJs = "Si";
   }   else { 
    datosPersona.interesPorJs = "No";    
   }
  
  }
  
  function renderizarDatosUsuario() {
    /* ------------------- NO TOCAR NI ELIMINAR ESTA FUNCION. ------------------- */
    obtenerDatosDelUsuario();
    /* --------------- PUNTO 2: Escribe tu codigo a partir de aqui --------------- */
    const nombre = document.getElementById("nombre");
    nombre.textContent = datosPersona.nombre;

    const edad = document.getElementById ('edad');
    edad.textContent = datosPersona.edad;

    const ciudad = document.getElementById ('ciudad');
    ciudad.textContent = datosPersona.ciudad;

    const interesPorJs = document.getElementById ('javascript');
    interesPorJs.textContent = datosPersona.interesPorJs;
  
  
  }
  
  
  function recorrerListadoYRenderizarTarjetas() {
    /* ------------------ PUNTO 3: Escribe tu codigo desde aqui ------------------ */
    const tarjeta = document.getElementById ('fila');
      tarjeta.innerHTML = '';
      listado.forEach(listadoMaterias => { 
        tarjeta.innerHTML+= `
          <div class = "caja">
            <img src=${listadoMaterias.imgUrl} alt=${listadoMaterias.lenguajes}>
            <p class = "lenguajes"> Lenguajes: ${listadoMaterias.lenguajes}</p>
            <p class = "bimestre"> Bimestre:  ${listadoMaterias.bimestre}</p>
          </div>
          ` 
    });
  }  
  
  function alternarColorTema() {
    /* --------------------- PUNTO 4: Escribe tu codigo aqui --------------------- */
    const objeto = document.querySelector ('body');
    objeto.classList.toggle ('dark');

  
  }
  
  /* --------------------- PUNTO 5: Escribe tu codigo aqui --------------------- */
  let soyEsto = document.querySelector("#sobre-mi");
  document.addEventListener("keydown", (e) => {
      if(e.code == "KeyF") {
       soyEsto.classList.remove("oculto")
      }
})